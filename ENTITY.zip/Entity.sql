use EmployeeDetails
CREATE TABLE table_name(
   id int,
   Name nvarchar(20),
   address varchar,
   PRIMARY KEY( id )
);
use EmployeeDetails
CREATE TABLE Employee(
   id int,
   Name nvarchar(20),
   AddressLine nvarchar(20),
   PRIMARY KEY( id )
);
drop table table_name
use EmployeeDetails
insert into Employee Values('1','Shantanu','Gurgaon');
insert into Employee Values('2','Bonzi','Dehradun');
drop table Employee
use EmployeeDetails
CREATE TABLE Employee(
   id int,
   Name nvarchar(20),
   AddressLine nvarchar(20),
   PRIMARY KEY( id )
);
select * from Employee